﻿using Amazon.DynamoDBv2;
using Amazon.Runtime;
using Orleans.Hosting;
using RestaurantOrderingSystem.Configurations;

var builder = Host.CreateDefaultBuilder();

builder.ConfigureAppConfiguration((hostingContext, config) =>
{
    config.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
});

builder.ConfigureWebHostDefaults(webBuilder =>
{
    webBuilder.ConfigureServices((context, services) =>
    {
        services.Configure<AWSSettings>(context.Configuration.GetSection("AWS"));
        services.AddSingleton<IOrderService,DynamoDBOrderService>();
        services.AddControllers();
        services.AddLogging();
        services.AddEndpointsApiExplorer();
        services.AddSwaggerGen();
    })
    .Configure(app =>
    {
        var env = app.ApplicationServices.GetRequiredService<IWebHostEnvironment>();
        if (env.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }
        app.UseRouting();
        app.UseAuthorization();
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
        });
    });
});

var configuration = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .Build();

var awsAccessKey = configuration["AWS:AccessKey"];
var awsSecretKey = configuration["AWS:SecretKey"];
var awsRegion = configuration["AWS:Region"];

var awsCredentials = new BasicAWSCredentials(awsAccessKey, awsSecretKey);
var dynamoDbConfig = new AmazonDynamoDBConfig
{
    RegionEndpoint = Amazon.RegionEndpoint.GetBySystemName(awsRegion)
};

var dynamoDbClient = new AmazonDynamoDBClient(awsCredentials, dynamoDbConfig);

builder.UseOrleans(siloBuilder =>
{
    siloBuilder
        .UseLocalhostClustering()
        .AddMemoryGrainStorage("OrleansGrainStorage")
        .AddDynamoDBGrainStorage(
        name: "OrleansGrainStorage",
        configureOptions: options =>
        {
            options.AccessKey = "AKIAQE3RORXUL54D5BOT";
            options.SecretKey = "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";
            options.Service = "eu-west-2";
        })
        .ConfigureLogging(logging => logging.AddConsole());
}
);


var host = builder.Build();
await host.RunAsync();



