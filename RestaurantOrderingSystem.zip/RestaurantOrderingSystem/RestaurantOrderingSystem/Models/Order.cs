﻿using System.Text.Json.Serialization;

namespace RestaurantOrderingSystem.Models
{
    [GenerateSerializer,Immutable]
    public class Order
    {
        public string OrderId { get; set; }
        public List<OrderItem> Items { get; set; } = new List<OrderItem>();
        public decimal TotalAmount { get; set; }
        public OrderStatus Status { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
