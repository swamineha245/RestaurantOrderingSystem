﻿using Orleans.Concurrency;
using Orleans.Runtime;
using RestaurantOrderingSystem.Grains.Interfaces;
using RestaurantOrderingSystem.Models;
using Orleans;
using System.Threading.Tasks;
using System.Threading;

namespace RestaurantOrderingSystem.Grains.Implementations
{
    public class OrderGrain : Grain, IOrderGrain
    {
        private readonly IPersistentState<Order> _orderState;

        public OrderGrain([PersistentState("order", "OrleansGrainStorage")] IPersistentState<Order> orderState)
        {
            _orderState = orderState;
        }

        public override async Task OnActivateAsync(CancellationToken cancellationToken)
        {
            await base.OnActivateAsync(cancellationToken);
        }

        public Task<Order> GetOrder()
        {
            return Task.FromResult(_orderState.State);
         
        }
        public async Task CreateOrder(Order order)
        {
            _orderState.State = order;
            await _orderState.WriteStateAsync();
        }

        public async Task UpdateOrderStatus(OrderStatus status)
        {
            _orderState.State.Status = status;
            await _orderState.WriteStateAsync();
        }

        public async Task UpdateOrder(Order order)
        {
            _orderState.State = order;
            await _orderState.WriteStateAsync();
        }

    }
}
