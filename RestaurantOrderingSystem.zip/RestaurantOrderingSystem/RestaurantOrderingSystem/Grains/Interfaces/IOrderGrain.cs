﻿using RestaurantOrderingSystem.Models;

namespace RestaurantOrderingSystem.Grains.Interfaces
{
    public interface IOrderGrain : IGrainWithStringKey
    {
        Task<Order> GetOrder();
        Task CreateOrder(Order order);
        Task UpdateOrderStatus(OrderStatus status);
        Task UpdateOrder(Order order);
       
    }
}
