﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RestaurantOrderingSystem.Grains.Interfaces;
using RestaurantOrderingSystem.Models;
using Microsoft.Extensions.Logging;

namespace RestaurantOrderingSystem.Controllers
{
    [ApiController]
    [Route("api/orders")]
    public class OrderController : ControllerBase
    {
        private readonly IClusterClient _orleansClient;
        private readonly IGrainFactory _grainfactory;
        private readonly ILogger<OrderController> _logger;
        private readonly IOrderService _orderService;
        public OrderController(IClusterClient orleansClient, IGrainFactory grainfactory, ILogger<OrderController> logger, IOrderService dynamoDBOrderService)
        {
            _orleansClient = orleansClient;
            _grainfactory = grainfactory;
            _logger = logger;
            _orderService = dynamoDBOrderService;
        }

        [HttpPost]
        public async Task<IActionResult> CreateOrder([FromBody] Order order)
        {
            try
            {
                var orderGrain = _grainfactory.GetGrain<IOrderGrain>(order.OrderId);

                await orderGrain.CreateOrder(order);
                await _orderService.SaveOrderAsync(order);
                return Ok(order);
            }
            catch(Exception ex)
            {
                return BadRequest(new
                {
                    success = false,
                    message = ex.Message
                });
            }

        }

        [HttpGet("{orderId}")]
        public async Task<IActionResult> GetOrder(string orderId)
        {
            _logger.LogInformation("Fetching order with orderId: {OrderId}", orderId);

            var order = await _orderService.GetOrderAsync(orderId);
            if (order == null)
            {
                _logger.LogWarning("Order with ID {OrderId} not found", orderId);
                return NotFound();
            }

            return Ok(order);

        }


        [HttpPut("{orderId}/status")]
        public async Task<IActionResult> UpdateOrderStatus(string orderId, [FromBody] OrderStatus status)
        {

            try
            {
                var orderGrain = _grainfactory.GetGrain<IOrderGrain>(orderId);
                var orderToUpdate = await orderGrain.GetOrder();

                if (orderToUpdate == null)
                {
                    return NotFound(new { message = "Order not found in Orleans." });
                }

                orderToUpdate.Status = status;
                await orderGrain.UpdateOrder(orderToUpdate); 

                bool updateResult = await _orderService.UpdateOrderStatusAsync(orderId, status);

                if (!updateResult)
                {
                    return BadRequest(new { message = "Failed to update status in DynamoDB." });
                }

                return Ok(new { message = "Order status updated successfully." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }

        }


    }
}
