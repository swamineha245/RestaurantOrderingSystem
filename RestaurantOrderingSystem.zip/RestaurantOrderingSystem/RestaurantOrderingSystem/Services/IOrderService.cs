﻿using RestaurantOrderingSystem.Models;

public interface IOrderService
{
    Task SaveOrderAsync(Order order);
    Task<Order> GetOrderAsync(string orderId);
    Task<bool> UpdateOrderStatusAsync(string orderId, OrderStatus newStatus);
}
