﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using Microsoft.Extensions.Options;
using RestaurantOrderingSystem.Configurations;
using RestaurantOrderingSystem.Models;
using System.Threading.Tasks;

using RestaurantOrderingSystem.Models;

public class DynamoDBOrderService : IOrderService
{
    private readonly AmazonDynamoDBClient _dynamoDBClient;
    private readonly DynamoDBContext _context;
    
    public DynamoDBOrderService(IOptions<AWSSettings> awsSettings)
    {
        _dynamoDBClient = new AmazonDynamoDBClient(awsSettings.Value.AccessKey, awsSettings.Value.SecretKey, Amazon.RegionEndpoint.GetBySystemName(awsSettings.Value.Region));
        _context = new DynamoDBContext(_dynamoDBClient);
    }


    public async Task SaveOrderAsync(Order order)
    {
        await _context.SaveAsync(order);
    }

    public async Task<Order> GetOrderAsync(string orderId)
    {
        return await _context.LoadAsync<Order>(orderId);
    }

    public async Task<bool> UpdateOrderStatusAsync(string orderId, OrderStatus newStatus)
    {
        try
        {
            var order = await _context.LoadAsync<Order>(orderId);

            if (order == null)
            {
                return false;
            }

            order.Status = newStatus;

            await _context.SaveAsync(order, new DynamoDBOperationConfig
            {
            });

            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error updating order status: {ex.Message}");
            return false; 
        }
    }


}
