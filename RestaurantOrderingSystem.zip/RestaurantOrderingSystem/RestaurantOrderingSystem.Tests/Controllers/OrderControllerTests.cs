﻿using Moq;
using Xunit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RestaurantOrderingSystem.Controllers;
using RestaurantOrderingSystem.Grains.Interfaces;
using RestaurantOrderingSystem.Models;
using RestaurantOrderingSystem;
using System.Threading.Tasks;
using System;

namespace RestaurantOrderingSystem.Tests
{
    public class OrderControllerTests
    {
        private readonly Mock<IClusterClient> _mockOrleansClient;
        private readonly Mock<IGrainFactory> _mockGrainFactory;
        private readonly Mock<ILogger<OrderController>> _mockLogger;
        private readonly Mock<IOrderService> _mockOrderService;
        private readonly OrderController _controller;

        public OrderControllerTests()
        {
            // Initialize the mocks
            _mockOrleansClient = new Mock<IClusterClient>();
            _mockGrainFactory = new Mock<IGrainFactory>();
            _mockLogger = new Mock<ILogger<OrderController>>();
            _mockOrderService = new Mock<IOrderService>();

            // Initialize the controller with mocked dependencies
            _controller = new OrderController(_mockOrleansClient.Object, _mockGrainFactory.Object, _mockLogger.Object, _mockOrderService.Object);
        }

        [Fact]
        public async Task CreateOrder_ReturnsOk_WhenOrderIsCreatedSuccessfully()
        {
            // Arrange
            var order = new Order { OrderId = "123", Status = OrderStatus.InProgress };
            var orderGrainMock = new Mock<IOrderGrain>();
            _mockGrainFactory.Setup(f => f.GetGrain<IOrderGrain>(order.OrderId,null)).Returns(orderGrainMock.Object);
            _mockOrderService.Setup(service => service.SaveOrderAsync(order)).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.CreateOrder(order);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnedOrder = Assert.IsType<Order>(okResult.Value);
            Assert.Equal(order.OrderId, returnedOrder.OrderId);
        }

        [Fact]
        public async Task CreateOrder_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var order = new Order { OrderId = "123", Status = OrderStatus.InProgress};
            var exceptionMessage = "An error occurred while creating the order";
            var orderGrainMock = new Mock<IOrderGrain>();
            _mockGrainFactory.Setup(f => f.GetGrain<IOrderGrain>(order.OrderId, null)).Returns(orderGrainMock.Object);
            _mockOrderService.Setup(service => service.SaveOrderAsync(order)).Throws(new Exception(exceptionMessage));

            // Act
            var result = await _controller.CreateOrder(order) as BadRequestObjectResult;

            // Assertresult.StatusCode

            Assert.True(result.StatusCode== 400);

            
        }

        [Fact]
        public async Task GetOrder_ReturnsOk_WhenOrderIsFound()
        {
            // Arrange
            var orderId = "123";
            var order = new Order { OrderId = orderId, Status = OrderStatus.InProgress };
            _mockOrderService.Setup(service => service.GetOrderAsync(orderId)).ReturnsAsync(order);

            // Act
            var result = await _controller.GetOrder(orderId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnedOrder = Assert.IsType<Order>(okResult.Value);
            Assert.Equal(orderId, returnedOrder.OrderId);
        }

        [Fact]
        public async Task GetOrder_ReturnsNotFound_WhenOrderIsNotFound()
        {
            // Arrange
            var orderId = "123";
            _mockOrderService.Setup(service => service.GetOrderAsync(orderId)).ReturnsAsync((Order)null);

            // Act
            var result = await _controller.GetOrder(orderId);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public async Task UpdateOrderStatus_ReturnsOk_WhenStatusIsUpdatedSuccessfully()
        {
            // Arrange
            var orderId = "123";
            var status = OrderStatus.InProgress;
            var order = new Order { OrderId = orderId, Status = OrderStatus.InProgress };
            var orderGrainMock = new Mock<IOrderGrain>();
            _mockGrainFactory.Setup(f => f.GetGrain<IOrderGrain>(orderId, null)).Returns(orderGrainMock.Object);
            orderGrainMock.Setup(grain => grain.GetOrder()).ReturnsAsync(order);
            _mockOrderService.Setup(service => service.UpdateOrderStatusAsync(orderId, status)).ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateOrderStatus(orderId, status);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            //var response = Assert.IsType<dynamic>(okResult.Value);
            //Assert.Equal("Order status updated successfully.", response.message);
            var response = okResult.Value;
            Assert.True(response.ToString().Contains("Order status updated successfully."));
        }

        [Fact]
        public async Task UpdateOrderStatus_ReturnsBadRequest_WhenStatusUpdateFails()
        {
            // Arrange
            var orderId = "123";
            var status = OrderStatus.Cancelled;
            var order = new Order { OrderId = orderId, Status = OrderStatus.InProgress};
            var orderGrainMock = new Mock<IOrderGrain>();
            _mockGrainFactory.Setup(f => f.GetGrain<IOrderGrain>(orderId, null)).Returns(orderGrainMock.Object);
            orderGrainMock.Setup(grain => grain.GetOrder()).ReturnsAsync(order);
            _mockOrderService.Setup(service => service.UpdateOrderStatusAsync(orderId, status)).ReturnsAsync(false);

            // Act
            var result = await _controller.UpdateOrderStatus(orderId, status);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = badRequestResult.Value;
            Assert.True(response.ToString().Contains("Failed to update status in DynamoDB."));
        }
    }
}
